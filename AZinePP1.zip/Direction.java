// This class must have the code in the run() method, sub-program/routain to slove the maze;
//   seraches for the Java logo based on the provided path/direction algorithm

public class Direction extends Thread
{

	Maze maze;
	Position location;
	
	Direction(Maze maze, Position location) 
	{	
		this.maze = maze;
		this.location = location;
	}
	
	// this is the code part that needs to be programmed by students to solve the maze 
	// using the provided path/direction algorithm
	public void run()
	{

		// this is a SAMPLE code of moving the student image in the maze,
		// and updates the information in Position.jav GUI class, append text into the JTextArea object
		// you should delete this code and start your solution, you may just keep the part of updating the information
		// in the Position.java class, appending information into the JTextArea object
		
		while(!maze.isDone()) 
		{
			/*
			 * if (this.maze.moveDown()) { location.textArea.append("Moved to row " +
			 * maze.getCurrRow() + ", column " + maze.getCurrCol() + "\n"); continue; }
			 */
//			if (maze.getCurrCol() % 2 == 0) // If current column is even
//			{
//				if (this.maze.moveDown()) // Moves down if it is able to
//					if (maze.isDone()) {break;}
//				
//				else if (maze.getCurrRow() != maze.getHeight() - 1) // Checks to see if the reason it can't move is an obstacle 
//				{ 
//					this.maze.moveRight();
//					if(this.maze.isDone()) {break;}
//					 	
//					this.maze.moveDown();
//					if(this.maze.isDone()) {break;}
//					 	
//					this.maze.moveDown(); 
//					if(this.maze.isDone()) {break;}
//					 	
//					this.maze.moveLeft();
//					if(this.maze.isDone()) {break;}
//					 	
//					if (!this.maze.moveDown() && (maze.getCurrRow() == maze.getHeight() - 1)) // Checks to see if floor boundary has been reached
//					{ 
//						this.maze.moveRight();
//						if(this.maze.isDone()) {break;}
//					}	
//				}
//				else if (maze.getCurrRow() == maze.getHeight() - 1) // Checks if boundary has been reached
//				{
//					this.maze.moveRight();
//					if(this.maze.isDone()) {break;}
//				}
//					
//			} // End if
//			else // If current column is odd
//			{
//				if (!this.maze.moveUp())
//				{
//					this.maze.moveLeft();
//					if(maze.isDone())
//						break;
//					this.maze.moveUp();
//					if(maze.isDone())
//						break;
//					this.maze.moveUp();
//					if(maze.isDone())
//						break;
//					this.maze.moveRight();
//					if(maze.isDone())
//						break;
//				}
//				if (!this.maze.moveUp() && maze.getCurrRow() == 0)
//				{
//					this.maze.moveRight();
//					if(maze.isDone())
//						break;
//				}
//				else // If it can move up, then move up and check if logo is found
//				{
//					this.maze.moveUp();
//					if(maze.isDone())
//						break;
//				}
//			} // End else
			if ((maze.getCurrCol() % 2) == 0) {
				
				if (this.maze.moveDown())	{
				
					location.textArea.append("Moved to row " + maze.getCurrRow() + ", column " + maze.getCurrCol() + "\n" + "Success" + "\n");
					if (maze.isDone())
						break;
				}
				
				else if ((!this.maze.moveDown()) && (maze.getCurrRow() != maze.getHeight() - 1))	{								
						
						location.textArea.append("Moved to row " + (maze.getCurrRow()+1) + ", column " + maze.getCurrCol() + "\n" + "Failure" + "\n");
						this.maze.moveRight();										
						location.textArea.append("Moved to row " + maze.getCurrRow() + ", column " + maze.getCurrCol() + "\n" + "Success" + "\n");
						if (maze.isDone()) 
							break;
						this.maze.moveDown();
						location.textArea.append("Moved to row " + maze.getCurrRow() + ", column " + maze.getCurrCol() + "\n" + "Success" + "\n");
						if (maze.isDone()) 
							break;
						this.maze.moveDown();
						location.textArea.append("Moved to row " + maze.getCurrRow() + ", column " + maze.getCurrCol() + "\n" + "Success" + "\n");
						if (maze.isDone()) 
							break;
						this.maze.moveLeft();
						location.textArea.append("Moved to row " + maze.getCurrRow() + ", column " + maze.getCurrCol() + "\n" + "Success" + "\n");
						if (maze.isDone()) 
							break;										
				}
				
				else if ((!this.maze.moveDown()) && (maze.getCurrRow() == maze.getHeight() - 1)) {
						location.textArea.append("Can not move down anymore, it is out of range" + "\n" + "Failure" + "\n");
					
						this.maze.moveRight();
						location.textArea.append("Moved to row " + maze.getCurrRow() + ", column " + maze.getCurrCol() + "\n" + "Success" + "\n");
						if (maze.isDone()) 
							break;
					}							
				
			} // end If
			
			else  {
				
				 if (this.maze.moveUp()) {
					 
					 location.textArea.append("Moved to row " + maze.getCurrRow() + ", column " + maze.getCurrCol() + "\n" + "Success" + "\n");
					 if (maze.isDone())
						 break;
				 }
												
				 else if ((!this.maze.moveUp()) && maze.getCurrRow() != 0) {
					 
							location.textArea.append("Moved to row " + (maze.getCurrRow()-1) + ", column " + maze.getCurrCol() + "\n" + "Failure" + "\n");
							this.maze.moveLeft();
							location.textArea.append("Moved to row " + maze.getCurrRow() + ", column " + maze.getCurrCol() + "\n" + "Success" + "\n");
							if (maze.isDone()) 
								break;
							this.maze.moveUp();
							location.textArea.append("Moved to row " + maze.getCurrRow() + ", column " + maze.getCurrCol() + "\n" + "Success" + "\n");
							if (maze.isDone()) 
								break;
							this.maze.moveUp();
							location.textArea.append("Moved to row " + maze.getCurrRow() + ", column " + maze.getCurrCol() + "\n" + "Success" + "\n");
							if (maze.isDone()) 
								break;
							this.maze.moveRight();
							location.textArea.append("Moved to row " + maze.getCurrRow() + ", column " + maze.getCurrCol() + "\n" + "Success" + "\n");
							if (maze.isDone())
								break;
							
				 }
					 
				 else if (!this.maze.moveUp() && (maze.getCurrRow() == 0)) {
					 location.textArea.append("Can not move up anymore, it is out of range" + "\n" + "Failure" + "\n");
							
							this.maze.moveRight();
							location.textArea.append("Moved to row " + maze.getCurrRow() + ", column " + maze.getCurrCol() + "\n" + "Success" + "\n");						
							if (maze.isDone()) 
								break;
				}								
			}// end Else	
		} // End while	
		
		location.textArea.append("Logo found! \n");
		
	} // End run()
   
	
}
